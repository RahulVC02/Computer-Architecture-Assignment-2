#include <stdio.h>

int main() 
{
  int i, n;
  int a = 0;
  int b = 1;
  
  int nextnumber =a + b;
  printf("Enter the number of terms in your fibonnaci sequence: ");
  
  scanf("%d", &n);
  
  printf("The Fibonacci Series is : %d, %d, ", a, b);
  
  for (i = 3; i <= n; ++i) {
    printf("%d, ", nextnumber);
    a = b;
    b = nextnumber;
    nextnumber = a + b;
  }
  return 0;
}